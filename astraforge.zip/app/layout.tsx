import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AstraForge — your coding workspace",
  description: "Build, explore and refine your ideas in one persistent coding workspace.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
